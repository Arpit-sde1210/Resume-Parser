
# Django + AI Resume Parser
https://www.youtube.com/@ridwanray

# Tools & Services
- Django
- pytest
- Llama Machine Learning model

# Landing page
![Description of Image](home-page.png)

# Tests

![Description of Image](test-result.png)